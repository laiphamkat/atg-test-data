# katalon-gen5-qengineer-automation

# `Introduction` 
This framework is used for the dog-fooding using Gen5 to test Gen5 UI on TestOps (Test Management) and ensure the quality of Gen5 includes: local engine, keywords, UI recorder,...

### **Prerequisites**

<section>

- Node 16

</section>

---

### **Project **

<section>

[G5-Automation Framework](https://github.com/katalon-studio/katalon-gen5-qengineer-automation) installation is required to build [Katalon-G5](https://github.com/katalon-studio/katalon-g5)

# `Installation` 

## 1. Install Katalon CLI and Katalon Sideload to your system
Clone the build [Katalon-G5](https://github.com/katalon-studio/katalon-g5)

Type these commands:

```
npm install
npm run bootstrap
npm run incremental-build
npm run install-scripts
```

After running the above commands, you will able to use the katalon CLI and the @katalon-g5/engine-sideload package.

## 2. Install Automation FW
Clone the build [G5-Automation Framework](https://github.com/katalon-studio/katalon-gen5-qengineer-automation)
Type these commands:

```
npm i
```

### Guideline
```
katalon run <testCasePath> [--browser <browserName>] [--headless]
```

```
Parameters
run: Target this command to run a test case

<testCasePath>: A path to the test case file

--browser <browserName>: Specify a browser to run the test. one of these values: chrome, firefox, edge, safari. Default to "chrome"

--headless: Start browser in headless mode
```
# `Structure`
```
project
│   <project name>.prj
└─── profiles
│   │   default.glbl
│   │   custom.glbl
│   
└─── test-cases
|   │   test case A.ts
|   │   test case B.js
│   └── test case Sub-folder
│       │   test case A.ts
│       │   test case B.js
│
└─── object-repository
│   │   web test object A.rs
│   │   mobile test object B.rs
│   │   webservice test object C.rs
│   │   windows test object D.wrs
│   └── object Repository Sub-folder
│       │   web test object A.rs
│
└─── data-files
│   │   test data A.json
│
└─── test-suites
│   │   test suite A.ts
│   │   test suite A.js
│   └── test Suites Sub-folder
│       │   test suite D.ts
│       │   test suite D.js
│
└─── test-listeners
│   │   test listener A.js
│
└─── keywords
│   │   classA.js (default package)
│
└─── include
│   │   config
│   └── utils
│       │   utils.js
│
└─── pages
|   │   page A.ts
|   │   page B.js
│   └── page Sub-folder
│       │   page A.ts
│       │   page B.js
│
└─── resources
```
```
Explanation:
- profiles: can configure the testing environment in terms of data and behaviors through Global variables.
- test-cases: contain the test cases
- object-repository: contain data locator
- data-files: contain test data
- test-suites: contain test suites to run test cases
- test-listeners: contain test hooks
- keywords: contain custom keywords
- include:
    - config: setup environment
    - utils: contain helpers and utilities
- pages: contain pages for testing
- resources: contain resources (images, videos, logs)
```
## `High level system design` 
![title](resources/images/high_level_solution_design.png)# katalon-gen-5
