export default {
  txtFirstName: "first-name",
  txtLastName: "last-name",
  txtAddress: "address",
  txtPassword: "password",
  optRole: "role"
}