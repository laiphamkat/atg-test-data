export const demoPageTestData = 
    {
        UrlDemoPage: 'https://katalon-test.s3.amazonaws.com/aut/html/form.html',
        FirstName: 'First Name Test 1',
        LastName: 'Last Name Test 1',
        Address: 'Ho Chi Minh City',
        Password: 'acb123!@#ACB',
        PasswordEncrypted: '9199f7eb142a739480657451ced33628-U2FsdGVkX1/tbvSxuciDr5DoCxLvscTq0Sa0PsDzth8=',
        OptionValue: 'Technical Architect'
    }