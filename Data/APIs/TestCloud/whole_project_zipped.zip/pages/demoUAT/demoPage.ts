import { getSelectorById } from "../../include/utils/utils";
import demo_PageObj from "../../object_repository/web/demoAUT/demo_pageObj";

const getFirstNameLocator = getSelectorById(demo_PageObj.txtFirstName);
const getLastNameLocator = getSelectorById(demo_PageObj.txtLastName);
const getAddressLocator = getSelectorById(demo_PageObj.txtAddress);
const getPasswordLocator = getSelectorById(demo_PageObj.txtPassword);
const getRoleOptLocator = getSelectorById(demo_PageObj.optRole);

export {
  getFirstNameLocator,
  getLastNameLocator,
  getAddressLocator,
  getPasswordLocator,
  getRoleOptLocator,
};
