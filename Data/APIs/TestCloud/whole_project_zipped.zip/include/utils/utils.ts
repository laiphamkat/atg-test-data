export const getSelectorById = (locator: string) => {
    return "css=#" + locator;
  };

export const getSelectorByClass = (locator: string) => {
    return "css=." + locator;
  };  