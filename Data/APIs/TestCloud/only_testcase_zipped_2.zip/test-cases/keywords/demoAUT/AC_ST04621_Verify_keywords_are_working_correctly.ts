import katalon from "@katalon-studio/cloud-test";
import {
    getFirstNameLocator,
    getLastNameLocator,
    getAddressLocator,
    getPasswordLocator,
    getRoleOptLocator,
} from "../../../pages/demoUAT/demoPage";
import dataDemoUAT from '../../../data_files/demoAUT/demoUAT.json';

export default katalon.testCase("Verify keywords - only test case zipped 2", async ({ web }) => {
  //open the browser
  await web.openBrowser(dataDemoUAT.UrlDemoPage);

  await new Promise(r => setTimeout(r, 60000));

  await web.setText(getFirstNameLocator, dataDemoUAT.FirstName);

  await web.setText(getLastNameLocator, dataDemoUAT.LastName);

  await web.setText(getAddressLocator, dataDemoUAT.Address);

  await web.setEncryptedText(
    getPasswordLocator,
    dataDemoUAT.PasswordEncrypted
  );

  await web.selectOptionByValue(getRoleOptLocator, dataDemoUAT.OptionValue, false)
  const actualResults = await web.verifyElementVisible(getRoleOptLocator);
  console.assert(actualResults, "verifyElementVisible keyword works incorrectly");
});

